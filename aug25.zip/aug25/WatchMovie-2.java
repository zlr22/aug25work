import java.util.Scanner;
import java.util.Random;

public class WatchMovie {

    public static void main(String args[]) {
        Scanner price = new Scanner(System.in);
        String pprice ;
    
    
        System.out.println("Enter Price"); 
        price = pprice.nextLine();   
       
        System.out.println("Price: " + price);   
        
        Scanner rrating = new Scanner(System.in);
        String rrating ;
    
    
        System.out.println("Enter Price"); 
        rating = rrating.nextLine();   
       
        System.out.println("Rating: " + rating + "out of 5.");  
        
        
        
        
        

    }
}
